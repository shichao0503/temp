import sys
from pymongo import MongoClient

bak_client = MongoClient("localhost", 27018)
prd_client = MongoClient("mongodb://" + sys.argv[2] + ":" + sys.argv[3] + "@" + sys.argv[1] + "/admin")

databases = prd_client.database_names()
databases.remove('admin')
databases.remove('local')
while 'config' in databases:
  databases.remove('config')
while 'test' in databases:
  databases.remove('test')

for database in databases:
  collections = prd_client[database].collection_names()
  for collection in collections:
    table = database + "." + collection
    prd_count = prd_client[database][collection].find().count()
    bak_count = bak_client[database][collection].find().count()
    if bak_count == prd_count:
      print "the backup for collection " + table + "\033[32m is the newest!\033[0m"
    else:
      print "the backup for collection " + table + "\033[31m is not the newest!\033[0m"
      print "--> The count for prd collection " + table + " is " + str(prd_count)
      print "--> The count for backup collection " + table + " is " + str(bak_count)
