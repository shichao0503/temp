#!/bin/bash
set -e

# 获取备份目录的路径
homePath=$(pwd |awk -F '/script' '{print $1}')

# 加载环境函数库
. ./main/lib/envFunc

# 加载数据库备份函数库
. ./main/lib/mysqldumpFunc
. ./main/lib/xtrabackupFunc
. ./main/lib/mongodumpFunc
. ./main/lib/esSnapshotFunc
. ./main/lib/resourceCatalogFunc
. ./main/lib/installFunc
. ./main/lib/configureFunc

# 加载参数文件
allConfigFiles=$(ls main/config/ |grep Config$)
for configFile in $allConfigFiles
do
	if [ $configFile != crontabConfig -a $configFile != logrotateConfig ]
	then
		. ./main/config/$configFile
	fi
done

# 环境启动
case $1 in
	'backup')
	case $2 in
		'mysql')
		echo $allConfigFiles |grep -wq mysqlConfig \
		&& backupMysqlByMysqldump 2>&1 | tee -a main/logs/backupMysql.log || menuBackup
		;;
		'mysql_xtrabackup')
		echo $allConfigFiles |grep -wq mysqlConfig \
		&& backupMysqlByXtrabackup 2>&1 | tee -a main/logs/backupMysqlXtrabackup.log || menuBackup
		;;
		'exchange')
		echo $allConfigFiles |grep -wq exchangeConfig \
		&& backupExchangeByMysqldump 2>&1 | tee -a main/logs/backupExchange.log || menuBackup
		;;
		'mongo')
		echo $allConfigFiles |grep -wq mongoConfig \
		&& backupMongoByMongodump 2>&1 | tee -a main/logs/backupMongo.log || menuBackup
		;;
		'es')
		echo $allConfigFiles |grep -wq esConfig \
		&& backupESBySnapshot 2>&1 | tee -a main/logs/backupES.log || menuBackup
		;;
		'es_log')
		echo $allConfigFiles |grep -wq esLogConfig \
		&& backupESLogBySnapshot 2>&1 | tee -a main/logs/backupESLog.log || menuBackup
		;;
		'es_data')
		echo $allConfigFiles |grep -wq esDataConfig \
		&& backupESDataBySnapshot 2>&1 | tee -a main/logs/backupESData.log || menuBackup
		;;
		'resourceCatalog')
		echo $allConfigFiles |grep -wq resourceCatalogConfig \
		&& backupResourceCatalog 2>&1 | tee -a main/logs/backupResourceCatalog.log || menuBackup
		;;
		'all')
		for configFile in $allConfigFiles
		do
			if [ "$configFile" == "mysqlConfig" ]; then backupMysqlByMysqldump 2>&1 | tee -a main/logs/backupMysql.log; fi
			if [ "$configFile" == "exchangeConfig" ]; then backupExchangeByMysqldump 2>&1 | tee -a main/logs/backupExchange.log; fi
			if [ "$configFile" == "mongoConfig" ]; then backupMongoByMongodump 2>&1 | tee -a main/logs/backupMongo.log; fi
			if [ "$configFile" == "esConfig" ]; then backupESBySnapshot 2>&1 | tee -a main/logs/backupES.log; fi
			#if [ "$configFile" == "esLogConfig" ]; then backupESLogBySnapshot 2>&1 | tee -a main/logs/backupESLog.log; fi
			if [ "$configFile" == "esDataConfig" ]; then backupESDataBySnapshot 2>&1 | tee -a main/logs/backupESData.log; fi
			if [ "$configFile" == "resourceCatalogConfig" ]; then backupResourceCatalog 2>&1 | tee -a main/logs/backupResourceCatalog.log; fi
		done
		;;
		*)
		menuBackup
		;;
	esac
	;;
	'recovery_test')
	case $2 in
		'mysql')
		echo $allConfigFiles |grep -wq mysqlConfig \
		&& recoveryTestMysql 2>&1 | tee -a main/logs/recoverTest.log || menuRecoveryTest
		;;
		'mysql_xtrabackup')
		echo $allConfigFiles |grep -wq mysqlConfig \
		&& recoveryTestMysqlXtrabackup 2>&1 | tee -a main/logs/recoverTest.log || menuRecoveryTest
		;;
		'exchange')
		echo $allConfigFiles |grep -wq exchangeConfig \
		&& recoveryTestExchange 2>&1 | tee -a main/logs/recoverTest.log || menuRecoveryTest
		;;
		'mongo')
		echo $allConfigFiles |grep -wq mongoConfig \
		&& recoveryTestMongo 2>&1 | tee -a main/logs/recoverTest.log || menuRecoveryTest
		;;
		'es')
		echo $allConfigFiles |grep -wq esConfig \
		&& recoveryTestES 2>&1 | tee -a main/logs/recoverTest.log || menuRecoveryTest
		;;
		'es_log')
		echo $allConfigFiles |grep -wq esLogConfig \
		&& recoveryTestESLog 2>&1 | tee -a main/logs/recoverTest.log || menuRecoveryTest
		;;
		'es_data')
		echo $allConfigFiles |grep -wq esDataConfig \
		&& recoveryTestESData 2>&1 | tee -a main/logs/recoverTest.log || menuRecoveryTest
		;;
		'all')
		for configFile in $allConfigFiles
		do
			if [ "$configFile" == "mysqlConfig" ]; then recoveryTestMysql 2>&1 | tee -a main/logs/recoverTest.log; fi
			if [ "$configFile" == "exchangeConfig" ]; then recoveryTestExchange 2>&1 | tee -a main/logs/recoverTest.log; fi
			if [ "$configFile" == "mongoConfig" ]; then recoveryTestMongo 2>&1 | tee -a main/logs/recoverTest.log; fi
			if [ "$configFile" == "esConfig" ]; then recoveryTestES 2>&1 | tee -a main/logs/recoverTest.log; fi
			#if [ "$configFile" == "esLogConfig" ]; then recoveryTestESLog 2>&1 | tee -a main/logs/recoverTest.log; fi
			if [ "$configFile" == "esDataConfig" ]; then recoveryTestESData 2>&1 | tee -a main/logs/recoverTest.log; fi
		done
		;;
		*)
		menuRecoveryTest
		;;
	esac
	;;
	'install')
	case $2 in
		'pymongo')
		installPymongo 2>&1
		;;
		'logrotate')
		installLogrotate 2>&1
		;;
		'crontab')
		installCrontabs 2>&1
		;;
		*)
		menuInstall
		;;
	esac
	;;
	'add')
	case $2 in
		'logrotate')
		add_logrotate 2>&1 | tee -a main/logs/configure.log
		;;
		'crontab')
		add_crontab 2>&1 | tee -a main/logs/configure.log
		;;
		*)
		menuAdd
		;;
	esac
	;;
	'remove')
	case $2 in
		'logrotate')
		remove_logrotate 2>&1 | tee -a main/logs/configure.log
		;;
		'crontab')
		remove_crontab 2>&1 | tee -a main/logs/configure.log
		;;
		*)
		menuRemove
		;;
	esac
	;;
	*)
	menu
	;;
esac
